//
//  ViewController.swift
//  SumayResta
//
//  Created by macbook on 07/03/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var num1: UITextField!
    @IBOutlet weak var num2: UITextField!
    @IBOutlet weak var resultado: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

 
    @IBAction func suma(_ sender: Any) {
    let a = Int(num1.text!)
        let b = Int(num2.text!)
        if a == nil || b == nil {
            
        }
     resultado.text = String(a! + b!)
    }
    
    
    @IBAction func resta(_ sender: Any) {
        let a = Int(num1.text!)
        let b = Int(num2.text!)
        if a == nil || b == nil {
            
        }
   
    resultado.text = String(a! - b!)
    }
    

}

